(function () {

  function print(msg) {
    var element = document.getElementById("output234");
    if(element){
      element.innerHTML = element.innerHTML + "<div>" + msg + "</div>"
    }
  }


  const url = window.location.search;
  const ua = navigator.userAgent.toLowerCase();
  const regExpIntentParam = /[?&](nr\b)/;
  const isFilterRedirect = regExpIntentParam.test(url);
  const isSocNetRedirect = /instagram|fb|twitter/i.test(ua);
  print(ua);
  const intentRedirectKey = "intent";
  if (isFilterRedirect) {
    var defaultFallbackFilter = window.location.href.replace(regExpIntentParam, "");
    doRedirect(defaultFallbackFilter);
  }
  if (isSocNetRedirect) {
    var defaultFallbackSocNet = window.location.href;
    var redirect;
    if (isSessionStorageSupported()) {
      redirect = sessionStorage.getItem(intentRedirectKey);
      if (redirect == null) {
        sessionStorage.setItem(intentRedirectKey, "f");
        doRedirect(defaultFallbackSocNet);
      }
    } else {
      redirect = getCookie(intentRedirectKey);
      if (redirect == null) {
        createCookie(intentRedirectKey, "f", 5);
        doRedirect(defaultFallbackSocNet);
      }
    }
  }

  function isSessionStorageSupported() {
    try {
      const key = "t";
      window.sessionStorage.setItem(key, key);
      window.sessionStorage.removeItem(key);
      return true;
    } catch (e) {
      return false;
    }
  }

  function doRedirect(defaultFallback) {
      if (/android/i.test(ua)) {
          appAndroid = `googlechrome://navigate?url=${defaultFallback}`;
          window.location = appAndroid;
          window.setTimeout(function() {
            window.location = defaultFallback
            window.close();
          }, 500);
      } else if (/iphone|ipad|ipod/i.test(ua)) {
          var arr = defaultFallback.split("/");
          if (arr.length >= 2) {
              var domain = arr[2];
              appIOs = `googlechrome://${domain}`;
              window.location = appIOs;
          }
        window.setTimeout(function () {
          window.location = defaultFallback
          window.close();
        }, 500);
      } else {
          window.location = defaultFallback;
      }
  }

  function createCookie(name, value, minutes) {
    if (minutes) {
      var date = new Date();
      date.setTime(date.getTime() + (minutes * 60 * 1000));
      var expires = "; expires=" + date.toGMTString();
    } else {
      var expires = "";
    }
    document.cookie = name + "=" + value + expires + ";path=/";
  }

  function getCookie(name) {
    var matches = document.cookie.match(new RegExp(
            "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
    ));
    return matches ? decodeURIComponent(matches[1]) : undefined;
  }
})();
