<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />


    <meta name="HandheldFriendly" content="True" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
    <link rel="icon" type="image/x-icon" href="https://megawinner.net/Content/themes/mgw/shared/images/favicon.ico" />
    <title>Mega Winner</title>

    <link href="./bundles/css.css" rel="stylesheet" />

</head>

<body data-pagetheme="mw1">

    <style>
    .stage-1{
      top: 200px
    }
    @media (max-width:776px) {
    .stage-1{
      top: 100px
    }
}
    </style>



    <div class="stage-1" style="position:absolute; left: 0; right: 0; ">
        <section class="section-logo">
            <div class="yg-logo">
                <!-- <img src="./Content/themes/mgw/shared/images/mw1/yg/yg-logo.fs8.png" /> -->
            </div>
        </section>

        <section class="section-content">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 order-md-1 mb-2 mb-md-0">
                        <div class="box-content box-content-offer">
                            <div
                                class="box-content-inner h-100 d-flex flex-column justify-content-center align-items-center">
                                <span class="u__text--larger u__color--yellow u__text--uppercase"><strong>Exclusive
                                        offer</strong></span>
                                <span>We are giving our visitors</span>
                                <div class="u__text--large u__color--yellow u__text--uppercase banner-free-chances" style="text-align:center">
                                    <a href="#"    style="text-decoration:none; color: white;">
                                    Get 150 free spins and $10 immediately upon registration
                                </a>
                                </div>
                                <span>to be our next</span>
                                <span class="u__text--large u__text--uppercase banner-jackpot">
                                    Jackpot Winner
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="box-content">
                            <div class="box-content-inner">
                                <a href="#"   >
                                <video class="main-video"
                                    src="./vi3.mp4" autoplay loop muted
                                    playsinline></video>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="section-spin-now-below" id="scroll-to-bottom-button">
            <div>
                <i class="fa fa-caret-down"></i>
                <a href="#" class="scroll-link u__text--outline" style="text-decoration:none; color: white;" >REGISTER NOW!!!</a>
                <i class="fa fa-caret-down fa-right-arrow"></i>
            </div>
        </section>

    </div>


</body>

</html>